﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho
{
    class Menu
    {

        public string Nome { get; set; }
        public int Senha { get; set; }
        public int Id { get; set; }
        public string Data { get; set; }
        public string Data2 { get; set; } 
        public string Data3 { get; set; }



        public Menu(string nome, int fone, int id, string data, string data2, string data3)
        {
            Data = data;
            Data2 = data2;
            Data3 = data3;
            Nome = nome;
            Senha = Senha;
            Id = id;
        }

        public void alteraNome(string novoNome)
        {
            Nome = novoNome;
        }
        public void alterarData(string novoDia)
        {
            Data = novoDia;
        }
        public void alterarMes(string novoMes)
        {
            Data2 = novoMes;
        }
        public void alterarAno(string novoAno)
        {
            Data3 = novoAno;
        }







    }
}
