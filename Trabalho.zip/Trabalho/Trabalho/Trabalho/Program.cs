﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho
{
    class Program
    {
        
        static void Main(string[] args)
        {
      
                        
            Boolean continua = true;

            List<Menu> listaMenu = new List<Menu>();
          



            do
            {

                int qtdepessoas = listaMenu.Count();

                Console.WriteLine("Quantidade de pessoas cadastradas: " + qtdepessoas );
                Console.WriteLine("--Menu de cadastro--");
                Console.WriteLine("1 - Incluir");
                Console.WriteLine("2 - Alterar");
                Console.WriteLine("3 - Excluir");
                Console.WriteLine("4 - Listar");
                Console.WriteLine("5 - Pesquisar");
                Console.WriteLine("6 - Sair ");
                Console.WriteLine("Digite sua opção:");
                
                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":

                        Console.WriteLine("Cadastro de pessoa");
                        Console.Write("Nome: ");
                        string nome = Console.ReadLine();
                        Console.Write("Senha com numero: ");
                        int senha = Convert.ToInt32(Console.ReadLine());
                        Console.Write("id: ");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Digita o dia: ");
                        string data = Console.ReadLine();
                        Console.Write("Digita o mês: ");
                        string data2 = Console.ReadLine();
                        Console.Write("Digita o ano: ");
                        string data3 = Console.ReadLine();
                        Console.WriteLine("Data: " + data + "/" + data2 + "/" + data3);
                        listaMenu.Add(new Menu(nome, senha, id, data, data2, data3));
                        break;


                    case "2":
                        Console.WriteLine("Alterar");
                        Console.WriteLine("Indique o registro a ser alterado (ID): ");
                        int alterarNome = int.Parse(Console.ReadLine());
                        Menu alterar = listaMenu.Find(x => x.Id == alterarNome);



                        if(alterarNome != null)
                        {
                            Console.Write("Informe o novo Nome: ");
                            string novoNome = Console.ReadLine();
                            alterar.alteraNome(novoNome);
                            Console.WriteLine("Nome atualizado: " + novoNome);
                            Console.WriteLine("Informe um novo dia: ");
                            string novoDia = Console.ReadLine();
                            alterar.alterarData("Dia atualizado" + novoDia);
                            Console.WriteLine("Informe um novo mês: ");
                            string novoMes = Console.ReadLine();
                            alterar.alterarMes("Mês atualizado" + novoMes);
                            Console.WriteLine("Informe um novo ano: ");
                            string novoAno = Console.ReadLine();
                            alterar.alterarAno("Ano atualizado" + novoAno);
                            Console.WriteLine("Nova data: " + novoDia + "/" + novoMes + "/" + novoAno);



                        }

                        else
                        {
                            Console.WriteLine(" ¨¨Registro não existe¨¨ ");
                        }


                        break;
                    case "3":
                        Console.WriteLine("\n Excluir \n");
                        for (int i = 1; i < listaMenu.Count; i++)
                        {
                            foreach (Menu pessoa in listaMenu)
                            {
                                Console.WriteLine($"{i++} {pessoa.Nome}");
                            }
                        }

                        Console.WriteLine("Digite o ID do Usuário à ser excuido\n (posição do usuário na lista)");
                        int userDel = Int32.Parse(Console.ReadLine());
                        userDel--;

                        Console.WriteLine("Deseja realmente excluir esse cadastro?\n  (S) - (N)");
                        string excluir = Console.ReadLine();
                        excluir = excluir.ToUpper();

                        if (excluir == "S")
                        {
                            if (userDel <= listaMenu.Count)
                            {
                                listaMenu.RemoveAt(userDel);
                            }
                            else
                            {
                                Console.WriteLine("Usuário deletado.");
                            }
                        }


                        break;
                    case "4":
                        Console.WriteLine("Listar");
                        Console.WriteLine("Ordem - Nome. - Senha  - Id - Data \n");

                        for (float i = 0; i < listaMenu.Count; i++)
                        {
                            foreach (Menu p in listaMenu)
                            {
                                Console.WriteLine($"{i++} - {p.Nome} - {p.Senha} - {p.Id}");
                            }
                        }

                        break;
                    case "5":
                        Console.WriteLine("\n Pesquisar");
                        Console.WriteLine("Digite o Nome do usuário");
                        string receber = Console.ReadLine();
                        receber = receber.ToUpper();
                        Menu Pesquisar = listaMenu.Find(x => x.Nome == receber);
                        if (Pesquisar != null)
                        {
                            Console.WriteLine($"Nome: {Pesquisar.Nome}");
                            Console.WriteLine($"Id: {Pesquisar.Id}");
                            Console.WriteLine($"Senha: {Pesquisar.Senha}");
                            Console.WriteLine($"Data: {Pesquisar.Data}");
                        }
                        break;

                    case "6":
                        Console.WriteLine("Sistema encerrado" +
                            "");
                        continua = false;
                        break;

                    default:
                        Console.WriteLine("opcão nao existente.");
                        break;

                       
                }
            }

            while (continua);

            Console.ReadKey();
        }
    }
}
